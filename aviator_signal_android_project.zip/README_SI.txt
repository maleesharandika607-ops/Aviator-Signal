AVIATOR SIGNAL Android App Project

මෙය APK එකක් සෘජුවම නොව Android App source project එකයි.
APK එක build කිරීමට GitHub Actions workflow එක සකස් කර ඇත.

1. මෙම ZIP එක extract කරන්න.
2. GitHub account එකකට login වී අලුත් public හෝ private repository එකක් හදන්න.
3. ZIP එකේ ඇතුළත files සියල්ල repository එකට upload කරන්න.
4. GitHub repository එකේ Actions tab එකට යන්න.
5. 'Build AVIATOR SIGNAL APK' workflow එක තෝරා 'Run workflow' ඔබන්න.
6. Build එක සාර්ථක වූ පසු run එකේ Artifacts යටතේ aviator-signal-apk.zip download කරන්න.
7. ZIP එක extract කළාම app-debug.apk ලැබේ. ඒ APK එක WhatsApp හරහා යවන්න පුළුවන්.

සටහන: මෙම App එක දැනට Netlify website එක internet හරහා විවෘත කරයි.
Aviator ප්‍රතිඵල කලින් දැනගන්නා හැකියාවක් මෙයින් නොලැබේ.
